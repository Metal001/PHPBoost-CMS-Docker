<?php
/**
 * @copyright   &copy; 2005-2023 PHPBoost
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL-3.0
 * @author      Julien BRISWALTER <j1.seth@phpboost.com>
 * @version     PHPBoost 6.0 - last update: 2020 12 20
 * @since       PHPBoost 4.0 - 2014 05 09
 * @contributor Sebastien LARTIGUE <babsolune@phpboost.com>
*/

#####################################################
#                    French                         #
#####################################################

$lang['item.1.label']   = 'Combien font 4 + cinq ?';
$lang['item.1.answers'] = '9;neuf';
$lang['item.2.label']   = 'Combien y a-t-il de voyelles dans le mot ordinateur ?';
$lang['item.2.answers'] = '5;cinq';
?>
